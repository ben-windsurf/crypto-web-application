jQuery(document).ready(function(){
    var password = document.querySelector("#password");
      var exclamationIcon = password.nextElementSibling.querySelector(".exclamation");
      $(exclamationIcon).tooltip();

      function generatePasswordTooltip(password) {
        var requirements = [
          { regex: /[A-Z]/, fulfilled: false, message: "1 uppercase character" },
          { regex: /.{8,}/, fulfilled: false, message: "8 characters or more" },
          { regex: /\d/, fulfilled: false, message: "at least 1 number" },
          { regex: /[\W_]/, fulfilled: false, message: "at least 1 special character" }
        ];

        requirements.forEach(req => {
          if (req.regex.test(password)) {
            req.fulfilled = true;
          }
        });

        var tooltip = '<span>';
        requirements.forEach(req => {
          var iconClass = req.fulfilled ? 'check text-success' : 'exclamation text-danger';
          tooltip += `<i class="icon ${iconClass}"></i> ${req.message}<br>`;
        });
        tooltip += '</span>';

        return tooltip;
      }
      
      jQuery(password).keyup(function(){
        let newTitle = generatePasswordTooltip(this.value);
        $(exclamationIcon).attr('title', newTitle).attr('data-original-title', newTitle).tooltip('update').tooltip('show');
      });
});