var importExtraBuiltInEAs = function () {
  importBuiltInEA(
  		"day_data_viewer",
  		"An EA to open charts(v1.0)",
  		[{ // parameters
  			name: "symbolNames",
  	    value: "EUR/USD",
  	    required: false,
  	    type: PARAMETER_TYPE.STRING,
  	    range: null
  	  },{
  			name: "timeFrame",
  	    value: TIME_FRAME.H4,
  	    required: false,
  	    type: PARAMETER_TYPE.STRING,
  	    range: null
  		}],
  		function (context) { // Init()
  			var account = getAccount(context, 0)
  			var brokerName = getBrokerNameOfAccount(account)
  			var accountId = getAccountIdOfAccount(account)
  			var symbolNames = getEAParameter(context, "symbolNames").split(",")
  			var timeFrame = getEAParameter(context, "timeFrame")

        context.chartHandles = []
        for (var i in symbolNames) {
          context.chartHandles[symbolNames[i]] = getChartHandle(context, brokerName, accountId, symbolNames[i], timeFrame)
        }
        if (typeof window.symbolDashboard != "undefined") {
          window.symbolDashboard.dataContext = context
        }
  		},
  		function (context) { // Deinit()
  		},
  		function (context) { // OnTick()
        if (typeof window.symbolDashboard == "undefined") return

        var tick = getCurrentTick(context)
        var symbolName = tick.symbolName
      	var chartHandle = context.chartHandles[symbolName]

      	var arrHigh = getData(context, chartHandle, DATA_NAME.HIGH)
      	var arrLow = getData(context, chartHandle, DATA_NAME.LOW)
        var arrClose = getData(context, chartHandle, DATA_NAME.CLOSE)
        var arrLen = arrHigh.length
        window.symbolDashboard.ohlc[symbolName] = {
          h: arrHigh[arrLen - 2],
          l: arrLow[arrLen - 2],
          p: arrClose[arrLen - 3]
        }
  		},
  		function (context) { // OnTransaction()
  		}
  	)

  importBuiltInEA(
  		"add_chart",
  		"An EA only used to add chart for widget mode(v1.0)",
  		[{ // parameters
  			name: "symbolName",
  	    value: "EUR/USD",
  	    required: true,
  	    type: PARAMETER_TYPE.STRING,
  	    range: null
  	  },{
  			name: "timeFrame",
  	    value: TIME_FRAME.H1,
  	    required: true,
  	    type: PARAMETER_TYPE.STRING,
  	    range: null
  		}],
  		function (context) { // Init()
  			var brokerName = sharedShownBrokerName
  			var accountId = sharedAccount
  			var symbolName = getEAParameter(context, "symbolName")
  			var timeFrame = getEAParameter(context, "timeFrame")

  			context.chartHandle = getChartHandle(context, brokerName, accountId, symbolName, timeFrame)
  		},
  		function (context) { // Deinit()
  		},
  		function (context) { // OnTick()
  		},
  		function (context) { // OnTransaction()
  		}
  	)

  importBuiltInEA(
  		"main_ui_monitor",
  		"An EA only used for interacting with the main UI(v1.0)",
  		[],
  		function (context) { // Init()
        context.mainUiMonitor = {
          checkCommand: function () {
            setInterval(function () {
              var command = localStorage.getItem("command")
              if (typeof command != "undefined" && command != null) {
                var command = JSON.parse(command)
                localStorage.removeItem("command")
                if (command.op == "addChart") {
                  launchEA("add_chart", command.param)
                }
              }
            }, 1000)
          }
        }

        context.mainUiMonitor.checkCommand();
  		},
  		function (context) { // Deinit()
  		},
  		function (context) { // OnTick()
  		},
  		function (context) { // OnTransaction()
  		}
  	)
}
