var fxSymbols = [
  {symbolName: "AUD/CAD", displayName: "AUD/CAD", base: "AUD", term: "CAD"},
  {symbolName: "AUD/CHF", displayName: "AUD/CHF", base: "AUD", term: "CHF"},
  {symbolName: "AUD/JPY", displayName: "AUD/JPY", base: "AUD", term: "JPY"},
  {symbolName: "AUD/USD", displayName: "AUD/USD", base: "AUD", term: "USD"},
  {symbolName: "EUR/GBP", displayName: "EUR/GBP", base: "EUR", term: "GBP"},
  {symbolName: "EUR/JPY", displayName: "EUR/JPY", base: "EUR", term: "JPY"},
  {symbolName: "EUR/USD", displayName: "EUR/USD", base: "EUR", term: "USD"},
  {symbolName: "GBP/AUD", displayName: "GBP/AUD", base: "GBP", term: "AUD"},
  {symbolName: "GBP/CHF", displayName: "GBP/CHF", base: "GBP", term: "CHF"},
  {symbolName: "GBP/JPY", displayName: "GBP/JPY", base: "GBP", term: "JPY"},
  {symbolName: "GBP/USD", displayName: "GBP/USD", base: "GBP", term: "USD"},
  {symbolName: "USD/CAD", displayName: "USD/CAD", base: "USD", term: "CAD"},
  {symbolName: "USD/CHF", displayName: "USD/CHF", base: "USD", term: "CHF"},
  {symbolName: "USD/JPY", displayName: "USD/JPY", base: "USD", term: "JPY"}
];

var recommendedSymbols = [
  {symbolName: "EUR/GBP", displayName: "EUR/GBP"},
  {symbolName: "EUR/JPY", displayName: "EUR/JPY"},
  {symbolName: "EUR/USD", displayName: "EUR/USD"},
  {symbolName: "GBP/JPY", displayName: "GBP/JPY"},
  {symbolName: "GBP/USD", displayName: "GBP/USD"},
  {symbolName: "USD/JPY", displayName: "USD/JPY"}
];

var symbolDashboard = {
  bLoaded: false,
  favSymbols: null,
  symbolDataTable: null,
  symboldataTable: null,
  fx: fxSymbols,
  fxDataTable: null,
  fxdataTable: null,
  recommended: recommendedSymbols,
  symbolNames: [],
  allSymbols: [],
  allSymbols2: [],
  currencySymbols: [],
  ohlc: [],
  details: [],
  bid: [],
  ask: [],
  dataContext: null,
  latestDayDataView: 0,
  sortedSymbolNames: "",
  bChecked: false,
  init: function () {
    for (let i in this.fx) {
      this.allSymbols[this.fx[i].symbolName] = this.fx[i];
      this.allSymbols2[this.fx[i].displayName] = this.fx[i];
      this.currencySymbols[this.fx[i].symbolName] = this.fx[i].displayName;
    }
  },
  updateSymbols: function () {
    let favSymbols = null;
    if (typeof localStorage.favSymbols != "undefined") {
      favSymbols = JSON.parse(localStorage.getItem("favSymbols"));
    } else {
      favSymbols = this.recommended;
      localStorage.setItem("favSymbols", JSON.stringify(favSymbols));
    }
    this.favSymbols = favSymbols;

    let symbolNames = new Set();
    for (let i in favSymbols) {
      let info = getSymbolInfo(window.myConfig.shownBrokerName, window.myConfig.accountId, favSymbols[i].displayName);
      if (info != null) {
        this.details[favSymbols[i].displayName] = info;
        symbolNames.add(favSymbols[i].displayName);
        this.symbolNames[favSymbols[i].symbolName] = favSymbols[i].displayName;
        this.currencySymbols[favSymbols[i].symbolName] = info;
      } else {
        let that = this;
        setTimeout(function () {
          that.updateSymbols();
        }, 5000);
        return;
      }
    }
    let sorted = [...symbolNames].sort((a, b) => a - b).join(",");
    if (sorted != this.sortedSymbolNames) {
      this.sortedSymbolNames = sorted;
      let currTime = new Date().getTime();
      if (currTime - this.latestDayDataView > 5000) {
        this.latestDayDataView = currTime;
        launchEA("day_data_viewer", [{
          name: "symbolNames", value: this.sortedSymbolNames
        }]);
      }
    }
    this.renderFavorites();
    this.renderAllSymbols();
    if (!this.bChecked) {
      this.bChecked = true;
      this.checkAndUpdate();
    }
  },
  checkAndUpdate: function () {
    let that = this;
    if (this.dataContext == null) {
      setTimeout(function () {
        that.checkAndUpdate();
      }, 1000);
      return;
    }

    let bOk = true;
    for (let i in this.favSymbols) {
      let symbol = this.favSymbols[i];
      if (typeof this.bid[symbol.displayName] == "undefined" || typeof this.ask[symbol.displayName] == "undefined") {
        bOk = false;
        break;
      }

      if (typeof this.dataContext.chartHandles[symbol.displayName] == "undefined") {
        bOk = false;
        break;
      }

      let chartHandle = this.dataContext.chartHandles[symbol.displayName];
      let arrHigh = getData(this.dataContext, chartHandle, DATA_NAME.HIGH);
      let arrLow = getData(this.dataContext, chartHandle, DATA_NAME.LOW);
      let arrClose = getData(this.dataContext, chartHandle, DATA_NAME.CLOSE);
      if (typeof arrHigh == "undefined" || typeof arrLow == "undefined" || typeof arrClose == "undefined" || arrHigh.length == 0) {
        bOk = false;
        break;
      }

      let arrLen = arrHigh.length;
      this.ohlc[symbol.displayName] = {
        h: arrHigh[arrLen - 2],
        l: arrLow[arrLen - 2],
        p: arrClose[arrLen - 3]
      };
    }

    if (bOk) {
      this.updateSymbols();
      this.refresh();
    } else {
      setTimeout(function () {
        that.checkAndUpdate();
      }, 5000);
    }
  },
  refresh: function () {
    for (let i in this.favSymbols) {
      let symbol = this.favSymbols[i];
      this.updateBid(symbol.symbolName, this.bid[symbol.displayName]);
      this.updateAsk(symbol.symbolName, this.ask[symbol.displayName]);
    }
  },
  updateBid: function (symbolName, bid) {
    this.bid[this.allSymbols[symbolName].displayName] = bid;

    if (typeof this.symbolNames[symbolName] == "string") {
      let name = this.symbolNames[symbolName];
      let symbolId = symbolName.replaceAll("/", "_");
      let id = `#symbol_${symbolId}_b`;
      let prevB = parseFloat($(id).text());
      $(id).text(bid);
      if (bid > prevB) {
        $(id).prop("style", "color:green");
      } else {
        $(id).prop("style", "color:red");
      }
      if (typeof this.ohlc[name] != "undefined") {
        let ohlc = this.ohlc[name];
        id = `#symbol_${symbolId}_l`;
        $(id).text(ohlc.l);
        id = `#symbol_${symbolId}_h`;
        $(id).text(ohlc.h);
        id = `#symbol_${symbolId}_p`;
        $(id).text(bid > ohlc.p ? ((Math.round((bid - ohlc.p) * 10000 / ohlc.p) / 100) + "%") : ("-" + (Math.round((ohlc.p - bid) * 10000 / ohlc.p) / 100) + "%"));
        if (bid > ohlc.p) {
          $(id).prop("style", "color:green");
        } else {
          $(id).prop("style", "color:red");
        }
      }
    }
  },
  updateAsk: function (symbolName, ask) {
    this.ask[this.allSymbols[symbolName].displayName] = ask;

    if (typeof this.symbolNames[symbolName] == "string") {
      let name = this.symbolNames[symbolName];
      let symbolId = symbolName.replaceAll("/", "_");
      let id = `#symbol_${symbolId}_a`;
      let prevA = parseFloat($(id).text());
      $(id).text(ask);
      if (ask > prevA) {
        $(id).prop("style", "color:green");
      } else {
        $(id).prop("style", "color:red");
      }
      if (typeof this.ohlc[name] != "undefined") {
        let ohlc = this.ohlc[name];
        id = `#symbol_${symbolId}_l`;
        $(id).text(ohlc.l);
        id = `#symbol_${symbolId}_h`;
        $(id).text(ohlc.h);
        id = `#symbol_${symbolId}_p`;
        $(id).text(ask > ohlc.p ? ((Math.round((ask - ohlc.p) * 10000 / ohlc.p) / 100) + "%") : ("-" + (Math.round((ohlc.p - ask) * 10000 / ohlc.p) / 100) + "%"));
        if (ask > ohlc.p) {
          $(id).prop("style", "color:green");
        } else {
          $(id).prop("style", "color:red");
        }
      }
    }
  },
  renderFavorites: function () {
    if (!$.fn.dataTable.isDataTable("#symbolTable")) {
      let table = $("#symbolTable").DataTable({
        columns: [{
            title: "Symbol1",
            render: function (data, type, row) {
              let symbolName = row[3];
              let symbolId = data.replaceAll("/", "_");
              return `<div class="sym-symbol text-primary">${symbolName}</div>
                      <div><span id="symbol_${symbolId}_p"></span><span id="symbol_${symbolId}_s"></span></div>`;
              }
          }, {
            title: "Symbol2",
            render: function (data, type, row) {
              let symbolId = data.replaceAll("/", "_");
              return `<div><span id="symbol_${symbolId}_b"></span></div><div>L:<span id="symbol_${symbolId}_l"></span></div>`;
            }
          }, {
            title: "Symbol3",
            render: function (data, type, row) {
              let symbolId = data.replaceAll("/", "_");
              return `<div><span id="symbol_${symbolId}_a"></span></div><div>H:<span id="symbol_${symbolId}_h"></span></div>`;
            }
          }
        ],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false,
      });

      let that = this;
      $("#symbolTable").on("click", "td", function () {
        let row = $(this).closest("tr");
        let data = that.symbolDataTable.row($(this).parents("tr")).data();

        let rowOffset = row.offset();
        let rowWidth = row.outerWidth();
        let rowHeight = row.outerHeight();

        let overlay = $(".symbol-overlay");
        if (overlay.length === 0) {
          overlay = $(`<div class="symbol-overlay"><span id="currentSymbol"></span>
            <button type="button" class="btn btn-default" id="btnDeleteFavSymbol"><i class="bi bi-bucket"></i></button>
            <button type="button" class="btn btn-primary" id="btnShowOrderFormBuy">BUY</button>
            <button type="button" class="btn btn-danger" id="btnShowOrderFormSell">SELL</button>
            <button type="button" class="btn btn-success" id="btnAddChart"><i class="bi bi-bar-chart"></i></button></div>`);
          $("body").append(overlay);

          $("#btnDeleteFavSymbol").on("click", function () {
            symbolDashboard.deleteFavSymbol($("#currentSymbol").text());
          })

          $("#btnShowOrderFormBuy").on("click", function () {
            symbolDashboard.showOrderForm($("#currentSymbol").text(), "BUY");
          })

          $("#btnShowOrderFormSell").on("click", function () {
            symbolDashboard.showOrderForm($("#currentSymbol").text(), "SELL");
          })

          $("#btnAddChart").on("click", function () {
            symbolDashboard.addChart($("#currentSymbol").text());
          })
        }

        $("#currentSymbol").text(data[0]);

        overlay.css({
          top: rowOffset.top,
          left: rowOffset.left,
          width: rowWidth,
          height: rowHeight,
          display: "block"
        });
      });

      this.symbolDataTable = $("#symbolTable").DataTable();
      this.symboldataTable = $("#symbolTable").dataTable();
    } else {
      let len = this.symbolDataTable.column(0).data().length;
      if (len > 0) {
        for (let i = len - 1; i >= 0; i--) {
          this.symboldataTable.fnDeleteRow(i);
        }
      }
    }

    for (let i in this.favSymbols) {
      let rowData = [this.favSymbols[i].symbolName, this.favSymbols[i].symbolName, this.favSymbols[i].symbolName, this.favSymbols[i].displayName];
      this.symbolDataTable.row.add(rowData).draw(false);
    }
  },
  addFavSymbol: function (symbol) {
    let favSymbols = JSON.parse(localStorage.getItem("favSymbols"));

    for (let i in favSymbols) {
      if (symbol.displayName == favSymbols[i].displayName) {
        return;
      }
    }

    favSymbols.push(symbol)
    localStorage.setItem("favSymbols", JSON.stringify(favSymbols));

    this.updateSymbols();
    this.refresh();
  },
  renderAllSymbols: function () {
    if (!$.fn.dataTable.isDataTable("#fxTable")) {
      let table = $("#fxTable").DataTable({
        columns: [{
            title: "Symbol"
          }, {
            title: "Action",
            render: function (data, type, row) {
              if (row[2] == 0) {
                return '<button class="btn btn-success" id="btnAddFavSymbol" title="Add favorite"><i class="bi bi-plus-circle"></i></button>';
              } else {
                return '<button class="btn btn-success" id="btnAddFavSymbol" title="Add favorite"><i class="bi bi-check"></i></button>';
              }
            }
          }
        ],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false,
      });

      this.fxDataTable = $("#fxTable").DataTable();
      this.fxdataTable = $("#fxTable").dataTable();

      let that = this;
      $("#fxTable tbody").on("click", "[id*=btnAddFavSymbol]", function () {
        if (that.fxDataTable != null) {
          let data = that.fxDataTable.row($(this).parents("tr")).data();

          let icon = $(this).find("i");

          if (icon.hasClass("bi-plus-circle")) {
            that.addFavSymbol({
              symbolName: data[1],
              displayName: data[0]
            });

            data[2] = 1;
            icon.removeClass("bi-plus-circle").addClass("bi-check");
          }
        }
      });
    } else {
      let len = this.fxDataTable.column(0).data().length;
      if (len > 0) {
        for (let i = len - 1; i >= 0; i--) {
          this.fxdataTable.fnDeleteRow(i);
        }
      }
    }

    for (let i in this.fx) {
      let rowData = [this.fx[i].displayName, this.fx[i].symbolName, 0];
      this.fxDataTable.row.add(rowData).draw(false);
    }
  },
  addChart: function (symbolName) {
    localStorage.setItem("command", JSON.stringify({
      op: "addChart",
      param: [{
        name: "symbolName", value: symbolName
      }, {
        name: "timeFrame", value: TIME_FRAME.M1
      }]
    }))
  },
  getFactor: function (symbol, currency) {
		let symbolForCrossRate = this.currencySymbols[currency + "/" + this.allSymbols2[symbol.symbolName].term];

		if (typeof symbolForCrossRate != "undefined") {
			if (typeof this.ask[symbolForCrossRate] == "undefined") {
				return 0.0;
			}

			return this.ask[symbolForCrossRate];
		} else {
			symbolForCrossRate = this.currencySymbols[this.allSymbols2[symbol.symbolName].term + "/" + currency];

			if (typeof symbolForCrossRate != "undefined") {
				if (typeof this.bid[symbolForCrossRate] == "undefined") {
					return 0.0;
				}

				return 1.0 / this.bid[symbolForCrossRate];
			} else {
				return 0.0;
			}
		}
	},
  calcCost: function (symbol, currency, price, lots) {
		if (window.myConfig.settings.spreadBetting == "true") {
			return price * lots * parseFloat(symbol.toFixed);
		} else {
			let lotsUnit = symbol.lotsUnit;

			if (currency == allSymbols2[symbol.symbolName].term) {
				return price * lots * lotsUnit;
			} else if (currency == allSymbols2[symbol.symbolName].base) {
				return lots * lotsUnit;
			} else {
				let currFactor = this.getFactor(symbol, currency);

				if (currFactor != 0.0) {
					return price * lots * lotsUnit / currFactor;
				} else {
					return 0.0;
				}
			}
		}
	},
  calcMargin: function (symbolName, lots, price) {
    let toFixed = parseInt(window.myConfig.settings.toFixed);
    let marginUsed = 0;
    let marginAvailable = 0;

    if (window.myConfig.settings.customMode == "1") {
			marginUsed = Math.round(lots * this.details[symbolName].leverage * toFixed) / toFixed;
      marginAvailable = Math.round((accountDashboard.summary.marginAvailable - marginUsed) * toFixed) / toFixed;
		} else {
      let symbol = this.details[symbolName];
      marginUsed = Math.round((this.calcCost(symbol, window.myConfig.settings.currency, price, lots) / this.details[symbolName].leverage) * toFixed) / toFixed;
      marginAvailable = Math.round((accountDashboard.summary.marginAvailable - marginUsed) * toFixed) / toFixed;
    }

    return {
      marginUsed: marginUsed,
      marginAvailable: marginAvailable
    }
  },
  showOrderForm: function (symbolName, orderType) {
    let symbolInfo = symbolDashboard.details[symbolName];
    let step = 10 / symbolInfo.toFixed;
    let mode = 1;
    $("#lotSizeMarket-" + mode).attr("step", symbolInfo.lotsStep);
    $("#lotSizeLimit-" + mode).attr("step", symbolInfo.lotsStep);
    $("#lotSizeStop-" + mode).attr("step", symbolInfo.lotsStep);

    $("#takeProfitMarket-" + mode).attr("step", step);
    $("#stopLossMarket-" + mode).attr("step", step);
    $("#triggerTargetLimit-" + mode).attr("step", step);
    $("#takeProfitLimit-" + mode).attr("step", step);
    $("#stopLossLimit-" + mode).attr("step", step);
    $("#triggerTargetStop-" + mode).attr("step", step);
    $("#takeProfitStop-" + mode).attr("step", step);
    $("#stopLossStop-" + mode).attr("step", step);

    $("#lotSizeMarket-" + mode).val(symbolInfo.lotsMinLimit);
    $("#lotSizeLimit-" + mode).val(symbolInfo.lotsMinLimit);
    $("#lotSizeStop-" + mode).val(symbolInfo.lotsMinLimit);

    $("#takeProfitMarket-" + mode).val(0);
    $("#stopLossMarket-" + mode).val(0);
    $("#takeProfitLimit-" + mode).val(0);
    $("#stopLossLimit-" + mode).val(0);
    $("#takeProfitStop-" + mode).val(0);
    $("#stopLossStop-" + mode).val(0);

    if (orderType == "BUY") {
      $("#triggerTargetLimit-" + mode).val(symbolDashboard.ask[symbolName]);
      $("#triggerTargetStop-" + mode).val(symbolDashboard.ask[symbolName]);
    } else {
      $("#triggerTargetLimit-" + mode).val(symbolDashboard.bid[symbolName]);
      $("#triggerTargetStop-" + mode).val(symbolDashboard.bid[symbolName]);
    }

    $("#orderModalLabel").text(symbolName);

    if (orderType == "BUY") {
      $("#marketPrice-1").text(symbolDashboard.ask[symbolName]);
      $("#orderTypeContainer").html(`<button type="button" class="btn btn-success margin-right" id="btnOrderType">${orderType}</button>`);
    } else if (orderType == "SELL") {
      $("#marketPrice-1").text(symbolDashboard.bid[symbolName]);
      $("#orderTypeContainer").html(`<button type="button" class="btn btn-danger margin-right" id="btnOrderType">${orderType}</button>`);
    }

    $("#btnOrderType").on("click", function () {
      if ($("#btnOrderType").text() == "BUY") {
        $("#btnOrderType").text("SELL");
        $("#btnOrderType").css("background", "red");
      } else {
        $("#btnOrderType").text("BUY");
        $("#btnOrderType").css("background", "green");
      }
    });
    $("#btnSendOrderMarket-" + mode).on("click", function () {
      let symbolNm = $("#orderModalLabel").text();
      let volume = parseFloat($("#lotSizeMarket-" + mode).val());
      let takeProfit = parseFloat($("#takeProfitMarket-" + mode).val());
      let stopLoss = parseFloat($("#stopLossMarket-" + mode).val());
      let orderType = null;
      if ($("#btnOrderType").text() == "BUY") {
        orderType = ORDER_TYPE.OP_BUY;
      } else {
        orderType = ORDER_TYPE.OP_SELL;
      }
      $("#btnSendOrderMarket-" + mode).prop("disabled", true);
      sendOrder(accountDashboard.brokerName, accountDashboard.accountId, symbolNm, orderType, 0, 0, volume, takeProfit, stopLoss, "", 0, 0);
      $("#orderModal").modal("hide");
      setTimeout(function () {
        $("#btnSendOrderMarket-" + mode).prop("disabled", false);
      }, 1000);
    });
    $("#btnSendOrderLimit-" + mode).on("click", function () {
      let symbolNm = $("#orderModalLabel").text();
      let price = parseFloat($("#triggerTargetLimit-" + mode).val());
      let volume = parseFloat($("#lotSizeLimit-" + mode).val());
      let takeProfit = parseFloat($("#takeProfitLimit-" + mode).val());
      let stopLoss = parseFloat($("#stopLossLimit-" + mode).val());
      let orderType = null;
      if ($("#btnOrderType").text() == "BUY") {
        orderType = ORDER_TYPE.OP_BUYLIMIT;
      } else {
        orderType = ORDER_TYPE.OP_SELLLIMIT;
      }
      $("#btnSendOrderLimit-" + mode).prop("disabled", true);
      sendOrder(accountDashboard.brokerName, accountDashboard.accountId, symbolNm, orderType, price, 0, volume, takeProfit, stopLoss, "", 0, 0);
      $("#orderModal").modal("hide");
      setTimeout(function () {
        $("#btnSendOrderLimit-" + mode).prop("disabled", false);
      }, 1000);
    });
    $("#btnSendOrderStop-" + mode).on("click", function () {
      let symbolNm = $("#orderModalLabel").text();
      let price = parseFloat($("#triggerTargetStop-" + mode).val());
      let volume = parseFloat($("#lotSizeStop-" + mode).val());
      let takeProfit = parseFloat($("#takeProfitStop-" + mode).val());
      let stopLoss = parseFloat($("#stopLossStop-" + mode).val());
      let orderType = null;
      if ($("#btnOrderType").text() == "BUY") {
        orderType = ORDER_TYPE.OP_BUYSTOP;
      } else {
        orderType = ORDER_TYPE.OP_SELLSTOP;
      }
      $("#btnSendOrderStop-" + mode).prop("disabled", true);
      sendOrder(accountDashboard.brokerName, accountDashboard.accountId, symbolNm, orderType, price, 0, volume, takeProfit, stopLoss, "", 0, 0);
      $("#orderModal").modal("hide");
      setTimeout(function () {
        $("#btnSendOrderStop-" + mode).prop("disabled", false);
      }, 1000);
    });
    $("#orderModal").modal("show");

    function calcMargin1 () {
      setTimeout(function () {
        calcMargin1();
        if ($("#marketPrice-1").text() != "") {
          if ($("#lotSizeMarket-1").val() != "") {
            let res = symbolDashboard.calcMargin(symbolName, parseFloat($("#lotSizeMarket-1").val()), parseFloat($("#marketPrice-1").text()));
            $("#marginRequiredMkt-1").text(res.marginUsed);
            $("#freeMarginMkt-1").text(res.marginAvailable);
          }
        }

        if ($("#triggerTargetLimit-1").val() != "") {
          if ($("#lotSizeLimit-1").val() != "") {
            let res = symbolDashboard.calcMargin(symbolName, parseFloat($("#lotSizeLimit-1").val()), parseFloat($("#triggerTargetLimit-1").val()));
            $("#marginRequiredLmt-1").text(res.marginUsed);
            $("#freeMarginLmt-1").text(res.marginAvailable);
          }
        }

        if ($("#triggerTargetStop-1").val() != "") {
          if ($("#lotSizeStop-1").val() != "") {
            let res = symbolDashboard.calcMargin(symbolName, parseFloat($("#lotSizeStop-1").val()), parseFloat($("#triggerTargetStop-1").val()));
            $("#marginRequiredStp-1").text(res.marginUsed);
            $("#freeMarginStp-1").text(res.marginAvailable);
          }
        }
      }, 1000);
    }
    calcMargin1();
  },
  deleteFavSymbol: function (symbolName) {
    let favSymbols = JSON.parse(localStorage.getItem("favSymbols"));

    for (let i in favSymbols) {
      if (symbolName == favSymbols[i].displayName) {
        favSymbols.splice(parseInt(i), 1);
        localStorage.setItem("favSymbols", JSON.stringify(favSymbols));
        break;
      }
    }

    symbolDashboard.updateSymbols();
    symbolDashboard.refresh();
  }
}

var accountDashboard = {
  summary: null,
  renderAcc: function(res) {
    if (res != null) {
      this.summary = res.account;
    }
  },
  updateAcc: function(res) {
    if (res != null) {
      this.summary.pl = res.account.pl;
      this.summary.balanceAndPL = res.account.balanceAndPL;
    }
  }
}

function toggleOrd(event) {
  const allOrd = document.querySelectorAll('.ord-order');
  const currentOrd = event.target.closest('.ord-order');
  const currentOrdPanel = currentOrd.querySelector('.ord-panel');
  const isOpen = currentOrdPanel.style.display === 'block';

  allOrd.forEach(ord => {
    ord.querySelector('.ord-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentOrdPanel.style.display = 'block';
  }
}

function togglePos(event) {
  const allPos = document.querySelectorAll('.pos-order');
  const currentPos = event.target.closest('.pos-order');
  const currentPosPanel = currentPos.querySelector('.pos-panel');
  const isOpen = currentPosPanel.style.display === 'block';

  allPos.forEach(pos => {
    pos.querySelector('.pos-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentPosPanel.style.display = 'block';
  }
}

function toggleHist(event) {
  const allHist = document.querySelectorAll('.pos-hist');
  const currentHist = event.target.closest('.pos-hist');
  const currentDetail = currentHist.querySelector('.hist-panel');
  const isOpen = currentDetail.style.display === 'block';

  allHist.forEach(hist => {
    hist.querySelector('.hist-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

var tradingDashboard = {
  ordersDataTable1: null,
  ordersdataTable1: null,
  ordersDataTable2: null,
  ordersdataTable2: null,
  orders: null,
  positionsDataTable1: null,
  positionsdataTable1: null,
  positionsDataTable2: null,
  positionsdataTable2: null,
  openTrades: null,
  historyDataTable1: null,
  historydataTable1: null,
  historyDataTable2: null,
  historydataTable2: null,
  history: null,
  swap: 0,
  commission: 0,
  originalValue: null,
  bBeingUsed: false,
  runCellEditor: function(dataTable, tableType, that, columnId, data) {
    console.log("Col " + columnId + " is clicked.")
    let cell = dataTable.cell(that);
    this.originalValue = cell.data();

    let container = $("<div>", {
      class: "editable-container"
    });

    let symbolInfo = typeof symbolDashboard.details[data[0]] == "undefined" ? getSymbolInfo(window.myConfig.shownBrokerName, window.myConfig.accountId, data[0]) : symbolDashboard.details[data[0]];
    symbolDashboard.details[data[0]] = symbolInfo;
    let step = 0.01;
    if (tableType == "order") {
      if (columnId == 4 || columnId == 5 || columnId == 6) {
        step = 10 / symbolInfo.toFixed;
      } else {
        step = symbolInfo.lotsStep;
      }
    } else if (tableType == "position") {
      if (columnId == 6 || columnId == 7) {
        step = 10 / symbolInfo.toFixed;
      }
    }

    // Create an input element
    let input = $("<input>", {
      type: "number",
      value: tradingDashboard.originalValue,
      class: "editable-input",
      step: step
    }).appendTo(container);

    let saveButton = $("<button>", {
      class: "editable-button btn btn-success btn-sm",
      html: '<i class="bi bi-check"></i>',
      click: function() {
        // Update the cell data and remove the container
        if (input.val()) {
          data[columnId] = input.val();
        } else {
          cell.data(tradingDashboard.originalValue).draw();
          return;
        }
        container.remove();
        tradingDashboard.bBeingUsed = false;
        if (tableType == "order") {
          modifyOrder(window.myConfig.shownBrokerName, window.myConfig.accountId, data[8], data[0], data[1], parseFloat(data[3]), 0, parseFloat(data[2]), parseFloat(data[4]), parseFloat(data[5]), "", 0, 0);
        } else {
          modifyTpSlOfTrade(window.myConfig.shownBrokerName, window.myConfig.accountId, data[10], parseFloat(data[5]), parseFloat(data[6]));
        }
      }
    }).appendTo(container);

    let cancelButton = $("<button>", {
      class: "editable-button btn btn-danger btn-sm",
      html: '<i class="bi bi-x-circle"></i>',
      click: function() {
        // Discard changes and remove the container
        cell.data(tradingDashboard.originalValue).draw();
        container.remove();
        tradingDashboard.bBeingUsed = false;
      }
    }).appendTo(container);

    $("body").append(container);
    let cellPosition = $(cell.node()).offset();
    container.css({
      top: cellPosition.top,
      left: cellPosition.left
    });

    input.focus();
  },
  genOrderRow: function (row) {
    let order = row;
    let orderId = order[8];
    let symbolName = order[0];
    let orderType = order[1].split(" ")[0];
    let price = null;
    let symbolInfo = typeof symbolDashboard.details[symbolName] == "undefined" ? getSymbolInfo(window.myConfig.shownBrokerName, window.myConfig.accountId, symbolName) : symbolDashboard.details[symbolName];
    symbolDashboard.details[symbolName] = symbolInfo;
    let step = 10 / symbolInfo.toFixed;
    let cls = null;
    if (orderType == "BUY") {
      if (typeof symbolDashboard.ask[symbolName] != "undefined") {
        price = symbolDashboard.ask[symbolName];
      } else {
        price = "";
      }
      cls = "primary";
    } else {
      if (typeof symbolDashboard.bid[symbolName] != "undefined") {
        price = symbolDashboard.bid[symbolName];
      } else {
        price = "";
      }
      cls = "danger";
    }

    let ordHtml =
    `<div class="ord-order">
      <div onclick="toggleOrd(event)" class="d-flex justify-content-between w-100 mt-2">
        <div>
            <div><span class="fw-bold" id="ord_symbol_${orderId}">${symbolName}</span>
                <span class="text-${cls}" id="ord_ordertype_${orderId}">${order[1]}</span><span class="text-sm text-${cls}">${order[2]}</span>
            </div>
            <div>${order[3]}<span><i class="bi bi-arrow-right mx-2"></i></span><span id="ord_price_${orderId}">${price}</span></div>
        </div>
      </div>

      <div class="ord-panel">
        <div class="d-flex justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">Lots:</div>
            <div class="order-modify"><input type="number" id="ord_lots_${orderId}" value="${order[2]}" class="ord-lots" step="${symbolInfo.lotsStep}" /><span id="ord_modl_${orderId}" class="editable-button btn btn-success btn-sm ord-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
          <div id="ord_cancelord_${orderId}" class="ord-cancelord">
            <div class="text-danger"><i class="bi bi-x-circle"></i></div>
          </div>
        </div>
        <div class="d-flex mt-3 justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">Price:</div>
            <div class="order-modify"><input type="number" id="ord_target_${orderId}" value="${order[3]}" class="ord-target" step="${step}" /><span id="ord_modp_${orderId}" class="editable-button btn btn-success btn-sm ord-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
        </div>
        <div class="d-flex mt-3 justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">SL:</div>
            <div class="order-modify"><input type="number" id="ord_sl_${orderId}" value="${order[5]}" class="ord-sl" step="${step}" /><span id="ord_mods_${orderId}" class="editable-button btn btn-success btn-sm ord-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
        </div>
        <div class="d-flex mt-3 justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">TP:</div>
            <div class="order-modify"><input type="number" id="ord_tp_${orderId}" value="${order[4]}" class="ord-tp" step="${step}" /><span id="ord_modt_${orderId}" class="editable-button btn btn-success btn-sm ord-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
        </div>
        <br>
        <div class="d-flex flex-column flex-md-row gap-4">
          <div class="d-flex gap-1">
            <div class="text-sm font-weight-bold">${order[6]}</div>
            <div class="text-sm">ID: </div>
            <div class="text-sm font-weight-bold">${orderId}</div>
          </div>
        </div>
      </div>
    </div>`;

    return ordHtml;
  },
  setupOrderTable: function () {
    $(".ord-cancelord").click(function() {
      let orderId = $(this).attr("id").split("_")[2];
      cancelOrder(window.myConfig.shownBrokerName, window.myConfig.accountId, orderId);
    });

    $(".ord-lots").on("focus", function() {
      $(".ord-mod").hide();
      let orderId = $(this).attr("id").split("_")[2];
      $("#ord_modl_" + orderId).show();
    });
    $(".ord-target").on("focus", function() {
      $(".ord-mod").hide();
      let orderId = $(this).attr("id").split("_")[2];
      $("#ord_modp_" + orderId).show();
    });
    $(".ord-sl").on("focus", function() {
      $(".ord-mod").hide();
      let orderId = $(this).attr("id").split("_")[2];
      $("#ord_mods_" + orderId).show();
    });
    $(".ord-tp").on("focus", function() {
      $(".ord-mod").hide();
      let orderId = $(this).attr("id").split("_")[2];
      $("#ord_modt_" + orderId).show();
    });

    $(".ord-mod").on("click", function() {
      $(".ord-mod").hide();
      let orderId = $(this).attr("id").split("_")[2];
      let symbolName = $("#ord_symbol_" + orderId).text();
      let orderType = $("#ord_ordertype_" + orderId).text();
      let price = $("#ord_target_" + orderId).val();
      let lots = $("#ord_lots_" + orderId).val();
      let takeProfit = $("#ord_sl_" + orderId).val();
      let stopLoss = $("#ord_tp_" + orderId).val();
      modifyOrder(window.myConfig.shownBrokerName, window.myConfig.accountId, orderId, symbolName, orderType, price, 0, lots, takeProfit, stopLoss, "", 0, 0);
    });
  },
  renderOrd: function(res, mode) {
    if (res != null) {
      this.orders = res.orders;
    }
    if (mode == 1) {
      if (!$.fn.dataTable.isDataTable("#orderTable-1")) {
        let table = $("#orderTable-1").DataTable({
          columns: [{
              title: "Symbol"
            },
            {
              title: "Type",
              render: function(data, type, row) {
                const orderBtnClass = data === 'BUY' ? 'buy-btn' : 'sell-btn';
                return `<span class="${orderBtnClass}">${data}</span>`;
              }
            },
            {
              title: "Lots"
            },
            {
              title: "Price"
            },
            {
              title: "TP"
            },
            {
              title: "SL"
            },
            {
              title: "Time"
            },
            {
              title: "Broker"
            },
            {
              title: "ID"
            },
            {
              title: "Action"
            }
          ],
          "columnDefs": [{
            targets: 7,
            visible: false
          }, {
            targets: -1,
            data: null,
            defaultContent:
            '<button class="btn btn-danger btn-close-trade" id="btnCancelOrder" title="Cancel order"><i class="bi bi-x-circle"></i></button>'
          }],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });

        this.ordersDataTable1 = $("#orderTable-1").DataTable();
        this.ordersdataTable1 = $("#orderTable-1").dataTable();

        let that = this;
        $("#orderTable-1 tbody").on("click", "td:nth-child(3)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.ordersDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.ordersDataTable1, "order", this, 3, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#orderTable-1 tbody").on("click", "td:nth-child(4)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.ordersDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.ordersDataTable1, "order", this, 4, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#orderTable-1 tbody").on("click", "td:nth-child(5)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.ordersDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.ordersDataTable1, "order", this, 5, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#orderTable-1 tbody").on("click", "td:nth-child(6)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.ordersDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.ordersDataTable1, "order", this, 6, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#orderTable-1 tbody").on("click", "[id*=btnCancelOrder]", function () {
          if (that.ordersDataTable1 != null) {
            let data = that.ordersDataTable1.row($(this).parents("tr")).data();

            cancelOrder(window.myConfig.shownBrokerName, window.myConfig.accountId, data[8]);
          }
        });
      } else {
        let len = this.ordersDataTable1.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.ordersdataTable1.fnDeleteRow(i);
          }
        }
      }

      for (let i in this.orders) {
        this.ordersDataTable1.row.add(this.orders[i]).draw(false);
      }
    } else {
      if (!$.fn.dataTable.isDataTable("#orderTable-2")) {
        let table = $("#orderTable-2").DataTable({
          columns: [{
              title: "Symbol",
              render: function(data, type, row) {
                return tradingDashboard.genOrderRow(row);
              }
            }
          ],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });

        this.ordersDataTable2 = $("#orderTable-2").DataTable();
        this.ordersdataTable2 = $("#orderTable-2").dataTable();
      } else {
        let len = this.ordersDataTable2.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.ordersdataTable2.fnDeleteRow(i);
          }
        }
      }

      for (let i in this.orders) {
        this.ordersDataTable2.row.add(this.orders[i]).draw(false);
      }

      this.setupOrderTable();
    }
  },
  renderAddedOrd: function(res, mode) {
    if (mode == 1) {
      if (typeof this.ordersDataTable1 != "undefined") {
        this.ordersDataTable1.row.add(res.order).draw(false);
      }
    } else {
      if (typeof this.ordersDataTable2 != "undefined") {
        this.ordersDataTable2.row.add(res.order).draw(false);
        this.setupOrderTable();
      }
    }
  },
  renderOrdAfterRm: function(res, mode) {
    if (mode == 1) {
      if (typeof this.ordersdataTable1 != "undefined") {
        this.ordersdataTable1.fnDeleteRow(res.rowId);
      }
    } else {
      if (typeof this.ordersdataTable2 != "undefined") {
        this.ordersdataTable2.fnDeleteRow(res.rowId);
      }
    }
  },
  genPositionRow: function (row) {
    let trade = row;
    let tradeId = trade[10];
    let symbolName = trade[0];
    let orderType = trade[1];
    let price = null;
    let symbolInfo = typeof symbolDashboard.details[symbolName] == "undefined" ? getSymbolInfo(window.myConfig.shownBrokerName, window.myConfig.accountId, symbolName) : symbolDashboard.details[symbolName];
    symbolDashboard.details[symbolName] = symbolInfo;
    let step = 10 / symbolInfo.toFixed;
    let cls = null;
    if (orderType == "BUY") {
      if (typeof symbolDashboard.bid[symbolName] != "undefined") {
        price = symbolDashboard.bid[symbolName];
      } else {
        price = "";
      }
      cls = "primary";
    } else {
      if (typeof symbolDashboard.ask[symbolName] != "undefined") {
        price = symbolDashboard.ask[symbolName];
      } else {
        price = "";
      }
      cls = "danger";
    }

    let posHtml =
    `<div class="pos-order">
      <div onclick="togglePos(event)" class="d-flex justify-content-between w-100 mt-2">
        <div>
            <div><span class="fw-bold" id="pos_symbol_${tradeId}">${symbolName}</span>
                <span class="text-${cls}" id="pos_ordertype_${tradeId}">${orderType}</span><span class="text-sm text-${cls}">${trade[3]}</span>
            </div>
            <div>${trade[4]}<span><i class="bi bi-arrow-right mx-2"></i></span><span id="pos_price_${tradeId}">${price}</span></div>
        </div>
        <div>
            <div class="fw-bold" id="pos_pl_${tradeId}">${trade[2]}</div>
        </div>
      </div>

      <div class="pos-panel">
        <div class="d-flex justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">SL:</div>
            <div class="order-modify"><input type="number" id="pos_sl_${tradeId}" value="${trade[6]}" class="pos-sl" step="${step}" /><span id="pos_mods_${tradeId}" class="editable-button btn btn-success btn-sm pos-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
          <div id="pos_closetrade_${tradeId}" class="pos-closetrade">
            <div class="text-danger"><i class="bi bi-x-circle"></i></div>
          </div>
        </div>
        <div class="d-flex mt-3 justify-content-between">
          <div class="d-flex align-items-center">
            <div class="panel-text">TP:</div>
            <div class="order-modify"><input type="number" id="pos_tp_${tradeId}" value="${trade[5]}" class="pos-tp" step="${step}" /><span id="pos_modt_${tradeId}" class="editable-button btn btn-success btn-sm pos-mod" style="display:none"><i class="bi bi-check"></i></span></div>
          </div>
        </div>
        <br>
        <div class="d-flex flex-column flex-md-row gap-4">
          <div class="d-flex gap-1">
            <div class="text-sm font-weight-bold">${trade[8]}</div>
            <div class="text-sm">Swap: </div>
            <div class="text-sm font-weight-bold" id="pos_swap_${tradeId}">${trade[7]}</div>
            <div class="text-sm">ID: </div>
            <div class="text-sm font-weight-bold">${tradeId}</div>
          </div>
        </div>
      </div>
    </div>`;

    return posHtml;
  },
  renderPositionColor: function (trade) {
    if (trade[2] >= 0) {
      $("#pos_pl_" + trade[10]).prop("style", "color:green");
    } else {
      $("#pos_pl_" + trade[10]).prop("style", "color:red");
    }
    if (trade[7] >= 0) {
      $("#pos_swap_" + trade[10]).prop("style", "color:green");
    } else {
      $("#pos_swap_" + trade[10]).prop("style", "color:red");
    }
  },
  setupPositionTable: function () {
    $(".pos-closetrade").click(function() {
      let tradeId = $(this).attr("id").split("_")[2];
      closeTrade(window.myConfig.shownBrokerName, window.myConfig.accountId, tradeId, 0, 0);
    });

    $(".pos-sl").on("focus", function() {
      $(".pos-mod").hide();
      let tradeId = $(this).attr("id").split("_")[2];
      $("#pos_mods_" + tradeId).show();
    });
    $(".pos-tp").on("focus", function() {
      $(".pos-mod").hide();
      let tradeId = $(this).attr("id").split("_")[2];
      $("#pos_modt_" + tradeId).show();
    });

    $(".pos-mod").on("click", function() {
      $(".pos-mod").hide();
      let tradeId = $(this).attr("id").split("_")[2];
      let takeProfit = $("#pos_sl_" + tradeId).val();
      let stopLoss = $("#pos_tp_" + tradeId).val();
      modifyTpSlOfTrade(window.myConfig.shownBrokerName, window.myConfig.accountId, tradeId, takeProfit, stopLoss);
    });
  },
  renderPos: function(res, mode) {
    if (res != null) {
      this.openTrades = res.trades;
    }
    if (mode == 1) {
      if (!$.fn.dataTable.isDataTable("#positionTable-1")) {
        let table = $("#positionTable-1").DataTable({
          columns: [{
              title: "Symbol"
            },
            {
              title: "Type",
              render: function(data, type, row) {
                const orderBtnClass = data === 'BUY' ? 'buy-btn' : 'sell-btn';
                return `<span class="${orderBtnClass}">${data}</span>`;
              }
            },
            {
              title: "Profit",
              render: function(data, type, row) {
                if (data >= 0) {
                  return '<span class="text-success">' + data + '</span>'
                } else {
                  return '<span class="text-danger">' + data + '</span>'
                }
              }
            },
            {
              title: "Lots"
            },
            {
              title: "Price"
            },
            {
              title: "TP"
            },
            {
              title: "SL"
            },
            {
              title: "Swap",
              render: function(data, type, row) {
                if (data >= 0) {
                  return '<span class="text-success">' + data + '</span>'
                } else {
                  return '<span class="text-danger">' + data + '</span>'
                }
              }
            },
            {
              title: "Time"
            },
            {
              title: "Broker"
            },
            {
              title: "ID"
            },
            {
              title: "Action"
            }
          ],
          "columnDefs": [{
            targets: 9,
            visible: false
          }, {
            targets: -1,
            data: null,
            defaultContent:
            '<button class="btn btn-danger btn-close-trade" id="btnCloseTrade" title="Close trade"><i class="bi bi-x-circle"></i></button>'
          }],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });

        this.positionsDataTable1 = $("#positionTable-1").DataTable();
        this.positionsdataTable1 = $("#positionTable-1").dataTable();

        let that = this;
        $("#positionTable-1 tbody").on("click", "td:nth-child(6)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.positionsDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.positionsDataTable1, "position", this, 6, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#positionTable-1 tbody").on("click", "td:nth-child(7)", function () {
          if (!that.bBeingUsed) {
            that.bBeingUsed = true;
            let data = that.positionsDataTable1.row($(this).parents("tr")).data();
            that.runCellEditor(that.positionsDataTable1, "position", this, 7, JSON.parse(JSON.stringify(data)));
          }
        });
        $("#positionTable-1 tbody").on("click", "[id*=btnCloseTrade]", function () {
          if (that.positionsDataTable1 != null) {
            let data = that.positionsDataTable1.row($(this).parents("tr")).data();

            closeTrade(window.myConfig.shownBrokerName, window.myConfig.accountId, data[10], 0, 0);
          }
        });
      } else {
        let len = this.positionsDataTable1.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.positionsdataTable1.fnDeleteRow(i);
          }
        }
      }

      for (let i in this.openTrades) {
        this.positionsDataTable1.row.add(this.openTrades[i]).draw(false);
      }
    } else {
      if (!$.fn.dataTable.isDataTable("#positionTable-2")) {
        let table = $("#positionTable-2").DataTable({
          columns: [{
              title: "Symbol",
              render: function(data, type, row) {
                return tradingDashboard.genPositionRow(row);
              }
            }
          ],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });

        this.positionsDataTable2 = $("#positionTable-2").DataTable();
        this.positionsdataTable2 = $("#positionTable-2").dataTable();
      } else {
        let len = this.positionsDataTable2.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.positionsdataTable2.fnDeleteRow(i);
          }
        }
      }

      for (let i in this.openTrades) {
        this.positionsDataTable2.row.add(this.openTrades[i]).draw(false);

        let trade = this.openTrades[i];
        this.renderPositionColor(this.openTrades[i]);
      }

      this.setupPositionTable();
    }
  },
  renderAddedPos: function(res, mode) {
    if (mode == 1) {
      if (typeof this.positionsDataTable1 != "undefined") {
        this.positionsDataTable1.row.add(res.trade).draw(false);
      }
    } else {
      if (typeof this.positionsDataTable2 != "undefined") {
        this.positionsDataTable2.row.add(res.trade).draw(false);

        this.renderPositionColor(res.trade);

        this.setupPositionTable();
      }
    }
  },
  renderPosAfterRm: function(res, mode) {
    if (mode == 1) {
      if (typeof this.positionsdataTable1 != "undefined") {
        this.positionsdataTable1.fnDeleteRow(res.rowId);
      }
    } else {
      if (typeof this.positionsdataTable2 != "undefined") {
        this.positionsdataTable2.fnDeleteRow(res.rowId);
      }
    }
  },
  updatePl1: function (rowId, pl) {
    if (this.openTrades == null || typeof this.openTrades[rowId] == "undefined") return;

    this.openTrades[rowId][2] = pl;
    if (typeof this.positionsdataTable1 != "undefined") {
      this.positionsdataTable1.fnUpdate(pl, rowId, 2, false, false);
    }
  },
  updatePl2: function (rowId, pl) {
    if (this.openTrades == null || typeof this.openTrades[rowId] == "undefined") return;

    let trade = this.openTrades[rowId];
    let id = trade[10];
    let symbolName = trade[0];
    let orderType = trade[1];
    let price = null;
    if (orderType == "BUY") {
      price = symbolDashboard.bid[symbolName];
    } else {
      price = symbolDashboard.ask[symbolName];
    }
    trade[2] = pl;
    $("#pos_price_" + id).text(price);
    $("#pos_pl_" + id).text(pl);
    if (pl >= 0) {
      $("#pos_pl_" + id).prop("style", "color:green");
    } else {
      $("#pos_pl_" + id).prop("style", "color:red");
    }
  },
  genHistoryRow: function (row) {
    let trade = row;
    let symbolName = trade[0];
    let orderType = trade[1];
    let cls = null;
    if (orderType == "BUY") {
      cls = "primary";
    } else {
      cls = "danger";
    }

    let histHtml =
    `<div class="pos-hist">
      <div onclick="toggleHist(event)" class="d-flex justify-content-between w-100 mt-2">
        <div>
            <div><span class="fw-bold" id="hist_symbol_${trade[10]}">${trade[0]}</span>
                <span class="text-${cls}" id="hist_ordertype_${trade[10]}">${trade[1]}</span><span class="text-sm text-${cls}">${trade[3]}</span>
            </div>
            <div>${trade[4]}<span><i class="bi bi-arrow-right mx-2"></i></span><span id="hist_price_${trade[10]}">${trade[5]}</span></div>
        </div>
        <div>
            <div class="text-align-right" id="hist_pl_${trade[10]}">${trade[2]}</div>
            <div class="small-text">${trade[8]}</div>
        </div>
      </div>

      <div class="hist-panel">
        <div class="d-flex align-items-center">
          <div>SL: <span class="text-danger">${trade[14]}</span></div>
        </div>
        <div class="d-flex align-items-center">
          <div>TP: <span class="text-success">${trade[13]}</span></div>
        </div>
        <div class="d-flex flex-column flex-md-row gap-4">
          <div class="d-flex gap-1">
            <div class="text-sm font-weight-bold">${trade[7]}</div>
            <div class="text-sm">Swap: </div>
            <div class="text-sm font-weight-bold" id="hist_swap_${trade[10]}">${trade[6]}</div>
            <div class="text-sm">Commission: </div>
            <div class="text-sm font-weight-bold text-danger">${trade[12]}</div>
            <div class="text-sm">ID: </div>
            <div class="text-sm font-weight-bold">${trade[10]}</div>
          </div>
        </div>
      </div>
    </div>`;

    return histHtml;
  },
  renderHistoryColor: function (trade) {
    if (trade[2] >= 0) {
      $("#hist_pl_" + trade[10]).prop("style", "color:green");
    } else {
      $("#hist_pl_" + trade[10]).prop("style", "color:red");
    }
    if (trade[6] >= 0) {
      $("#hist_swap_" + trade[10]).prop("style", "color:green");
    } else {
      $("#hist_swap_" + trade[10]).prop("style", "color:red");
    }
  },
  renderHist: function(res, mode) {
    if (res != null) {
      this.history = res.trades;
    }

    this.swap = 0;
    this.commission = 0;

    if (mode == 1) {
      if (!$.fn.dataTable.isDataTable("#historyTable-1")) {
        let table = $("#historyTable-1").DataTable({
          columns: [{
              title: "Symbol"
            },
            {
              title: "Type",
              render: function(data, type, row) {
                const orderBtnClass = data === 'BUY' ? 'buy-btn' : 'sell-btn';
                return `<span class="${orderBtnClass}">${data}</span>`;
              }
            },
            {
              title: "Profit",
              render: function(data, type, row) {
                if (data >= 0) {
                  return '<span class="text-success">' + data + '</span>'
                } else {
                  return '<span class="text-danger">' + data + '</span>'
                }
              }
            },
            {
              title: "Lots"
            },
            {
              title: "Open"
            },
            {
              title: "Close"
            },
            {
              title: "Swap",
              render: function(data, type, row) {
                if (data >= 0) {
                  return '<span class="text-success">' + data + '</span>'
                } else {
                  return '<span class="text-danger">' + data + '</span>'
                }
              }
            },
            {
              title: "Open Time"
            },
            {
              title: "Closed Time"
            },
            {
              title: "Broker"
            },
            {
              title: "ID"
            }
          ],
          "columnDefs": [{
            targets: 9,
            visible: false
          }],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });
      } else {
        let len = this.historyDataTable1.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.historydataTable1.fnDeleteRow(i);
          }
        }
      }
      this.historyDataTable1 = $("#historyTable-1").DataTable();
      this.historydataTable1 = $("#historyTable-1").dataTable();

      for (let i in this.history) {
        this.historyDataTable1.row.add(this.history[i]).draw(false);
        this.swap += this.history[i][6];
        this.commission += this.history[i][12];
      }
    } else {
      if (!$.fn.dataTable.isDataTable("#historyTable-2")) {
        let table = $("#historyTable-2").DataTable({
          columns: [{
              title: "Symbol",
              render: function(data, type, row) {
                return tradingDashboard.genHistoryRow(row);
              }
            }
          ],
          "paging": false,
          "lengthChange": false,
          "searching": false,
          "info": false,
          "autoWidth": false
        });
      } else {
        let len = this.historyDataTable2.column(0).data().length;
        if (len > 0) {
          for (let i = len - 1; i >= 0; i--) {
            this.historydataTable2.fnDeleteRow(i);
          }
        }
      }
      this.historyDataTable2 = $("#historyTable-2").DataTable();
      this.historydataTable2 = $("#historyTable-2").dataTable();

      for (let i in this.history) {
        let trade = this.history[i];

        this.historyDataTable2.row.add(trade).draw(false);

        this.renderHistoryColor(trade);

        this.swap += trade[6];
        this.commission += trade[12];
      }
    }

    let toFixed = parseInt(window.myConfig.settings.toFixed);
    this.swap = Math.round(this.swap * toFixed) / toFixed;
    this.commission = Math.round(this.commission * toFixed) / toFixed;
  },
  renderAddedHist: function(res, mode) {
    if (mode == 1) {
      if (typeof this.historyDataTable1 != "undefined") {
        this.historyDataTable1.row.add(res.trade).draw(false);
      }
    } else {
      if (typeof this.historyDataTable2 != "undefined") {
        this.historyDataTable2.row.add(res.trade).draw(false);
      }

      this.renderHistoryColor(res.trade);
    }

    let toFixed = parseInt(window.myConfig.settings.toFixed);
    let swap = Math.round((this.swap + res.trade[6]) * toFixed) / toFixed;
    let commission = Math.round((this.commission + res.trade[12]) * toFixed) / toFixed;
  }
}

var fundingDashboard = {
  deposit: 0,
  withdrawal: 0,
  paymentDataTable: null,
  paymentdataTable: null,
  payment: null,
  payoutDataTable: null,
  payoutdataTable: null,
  payout: null,
  renderUpdatedFunding: function(res) {
    if (res.trade[4] > 0) {
      if (typeof this.paymentDataTable != "undefined") {
        this.paymentDataTable.row.add(res.trade).draw(false);

        let toFixed = parseInt(window.myConfig.settings.toFixed);
        this.deposit = Math.round((this.deposit + res.trade[4]) * toFixed) / toFixed;
      }
    } else if (res.trade[4] < 0) {
      if (typeof this.payoutDataTable != "undefined") {
        this.payoutDataTable.row.add(res.trade).draw(false);

        let toFixed = parseInt(window.myConfig.settings.toFixed);
        this.withdrawal = Math.round((this.withdrawal + res.trade[4]) * toFixed) / toFixed;
      }
    }
  },
  renderPayment: function(res) {
    if (res != null) {
      this.payment = res.trades;
    }

    if (!$.fn.dataTable.isDataTable("#paymentTable")) {
      let table = $("#paymentTable").DataTable({
        columns: [{
            title: "Broker"
          },
          {
            title: "ID"
          },
          {
            title: "Payment"
          },
          {
            title: "Time"
          },
          {
            title: "Deposit"
          }
        ],
        "columnDefs": [{
          targets: 0,
          visible: false
        }],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false
      });
    } else {
      let len = this.paymentDataTable.column(0).data().length;
      if (len > 0) {
        for (let i = len - 1; i >= 0; i--) {
          this.paymentdataTable.fnDeleteRow(i);
        }
      }
    }
    this.paymentDataTable = $("#paymentTable").DataTable();
    this.paymentdataTable = $("#paymentTable").dataTable();

    let deposit = 0;

    for (let i in this.payment) {
      if (this.payment[i][4] > 0) {
        this.paymentDataTable.row.add(this.payment[i]).draw(false);
        deposit += this.payment[i][4];
      }
    }

    let toFixed = parseInt(window.myConfig.settings.toFixed);
    this.deposit = Math.round(deposit * toFixed) / toFixed;
  },
  renderPayout: function(res) {
    if (res != null) {
      this.payout = res.trades;
    }

    if (!$.fn.dataTable.isDataTable("#payoutTable")) {
      let table = $("#payoutTable").DataTable({
        columns: [{
            title: "Broker"
          },
          {
            title: "ID"
          },
          {
            title: "Payment"
          },
          {
            title: "Time"
          },
          {
            title: "Withdrawal"
          }
        ],
        "columnDefs": [{
          targets: 0,
          visible: false
        }],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false
      });
    } else {
      let len = this.payoutDataTable.column(0).data().length;
      if (len > 0) {
        for (let i = len - 1; i >= 0; i--) {
          this.payoutdataTable.fnDeleteRow(i);
        }
      }
    }
    this.payoutDataTable = $("#payoutTable").DataTable();
    this.payoutdataTable = $("#payoutTable").dataTable();

    let withdrawal = 0;

    for (let i in this.payout) {
      if (this.payout[i][4] < 0) {
        this.payoutDataTable.row.add(this.payout[i]).draw(false);
        withdrawal += this.payout[i][4];
      }
    }

    let toFixed = parseInt(window.myConfig.settings.toFixed);
    this.withdrawal = Math.round(withdrawal * toFixed) / toFixed;
  }
}

var cptdDashboard = {
  pro: [],
  copyTrading: [],
  lamm: [],
  pamm: [],
  followers: [],
  proDataTable: null,
  prodataTable: null,
  followingDataTable: null,
  followingdataTable: null,
  followerDataTable: null,
  followerdataTable: null,
  setCopyTradeProfile: function (cpTrdCommissionRate, cpTrdPeriod, signalName) {
    let formData = {
      "brokerName": window.myConfig.brokerName,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/setWatchable`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});

    formData = {
      "brokerName": window.myConfig.brokerName,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2,
      "funds": cpTrdCommissionRate,
      "level": cpTrdPeriod,
      "symbolName": signalName
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/sCTP`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  revokeCopyTrade: function () {
    let formData = {
      "brokerName": window.myConfig.brokerName,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/setNotWatchable`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  proposeCopyTrade: function (brokerId, accountId, mode, multiplier, bReverse) {
    let formData = {
      "brokerName": brokerId,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2,
      "reqAccountId": ((mode == 0 || mode == 1) ? window.myConfig.copyTradingPlatformId : accountId),
      "aBook": bReverse,
      "level": mode,
      "funds": multiplier,
      "comment": ((mode == 0 || mode == 1) ? (brokerId + ":" + accountId) : null)
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/pCT`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  disableCopyTrading: function (brokerId, accountId, mode) {
    let formData = {
      "brokerName": brokerId,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2,
      "reqAccountId": ((mode == 0 || mode == 1) ? window.myConfig.copyTradingPlatformId : accountId),
      "comment": ((mode == 0 || mode == 1) ? (brokerId + ":" + accountId) : null)
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/dCTI`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  disableCopyTraded: function (brokerId, accountId, mode) {
    let formData = {
      "brokerName": brokerId,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2,
      "reqAccountId": ((mode == 0 || mode == 1) ? window.myConfig.copyTradingPlatformId : accountId),
      "comment": ((mode == 0 || mode == 1) ? (brokerId + ":" + accountId) : null)
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/dCTE`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  approveCopyTrade: function (brokerId, accountId, mode) {
    let formData = {
      "brokerName": brokerId,
      "accountId": window.myConfig.accountId,
      "tradeToken": window.myConfig.tk2,
      "reqAccountId": accountId,
      "comment": null
    };

    $.ajax({
        type: "POST",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/aCT`,
        data: JSON.stringify(formData),
        headers: {
          "Content-Type": "application/json"
        }
      })
      .done(function(res) {
        if (res.res == "success") {

        }
      })
      .fail(function(data) {});
  },
  showCopyTradeForm: function (mode, brokerId, accountId) {
    if (mode == "cptd") {
      $("#btnProposeCptd-1").on("click", function () {
        let brkId = $("#brokerIdCptd-1").val();
        let accId = $("#accountIdCptd-1").val();
        let md = parseInt($('input[name="modeCptd-1"]:checked', '#copyTradeForm').val());
        let multiplier = $("#multiplierCptd-1").val();
        if (multiplier == "") {
          throw new Error("The multiplier is required.");
        }
        multiplier = parseFloat(multiplier);
        let bReverse = $("#reverseCptd-1").prop("checked");
        $("#cptdModal").modal("hide");
        cptdDashboard.proposeCopyTrade(brkId, accId, md, multiplier, bReverse);
      });
      $("#brokerIdCptd-1").val(brokerId);
      $("#accountIdCptd-1").val(accountId);
      $("#cptdModal").modal("show");
    } else if (mode == "lamm") {
      $("#btnProposeLamm-1").on("click", function () {
        let brkId = $("#brokerIdLamm-1").val();
        let accId = $("#accountIdLamm-1").val();
        let bReverse = $("#reverseLamm-1").prop("checked");
        $("#lammModal").modal("hide");
        cptdDashboard.proposeCopyTrade(brkId, accId, 2, 1, bReverse);
      });
      $("#brokerIdLamm-1").val(brokerId);
      $("#accountIdLamm-1").val(accountId);
      $("#lammModal").modal("show");
    } else if (mode == "pamm") {
      $("#btnProposePamm-1").on("click", function () {
        let brkId = $("#brokerIdPamm-1").val();
        let accId = $("#accountIdPamm-1").val();
        $("#pammModal").modal("hide");
        cptdDashboard.proposeCopyTrade(brkId, accId, 3, 1, false);
      });
      $("#brokerIdPamm-1").val(brokerId);
      $("#accountIdPamm-1").val(accountId);
      $("#pammModal").modal("show");
    }
  },
  showUnfollowForm: function (mode, brokerId, accountId) {
    if (mode == "Lots") {
      $("#modeUnfollow-1").val(0);
    } else if (mode == "Multiplier") {
      $("#modeUnfollow-1").val(1);
    } else if (mode == "LAMM") {
      $("#modeUnfollow-1").val(2);
    } else if (mode == "PAMM") {
      $("#modeUnfollow-1").val(3);
    }

    $("#btnUnfollow").on("click", function () {
      let brkId = $("#brokerIdUnfollow-1").val();
      let accId = $("#accountIdUnfollow-1").val();
      let md = parseInt($("#modeUnfollow-1").val());
      $("#unfollowModal").modal("hide");
      cptdDashboard.disableCopyTrading(brkId, accId, md);
    });

    $("#brokerIdUnfollow-1").val(brokerId);
    $("#accountIdUnfollow-1").val(accountId);
    $("#unfollowModal").modal("show");
  },
  showRejectForm: function (mode, accountId) {
    if (mode == "Lots") {
      $("#modeReject-1").val(0);
    } else if (mode == "Multiplier") {
      $("#modeReject-1").val(1);
    } else if (mode == "LAMM") {
      $("#modeReject-1").val(2);
    } else if (mode == "PAMM") {
      $("#modeReject-1").val(3);
    }

    $("#btnReject").on("click", function () {
      let brkId = $("#brokerIdReject-1").val();
      let accId = $("#accountIdReject-1").val();
      let md = parseInt($("#modeReject-1").val());
      $("#rejectModal").modal("hide");
      cptdDashboard.disableCopyTraded(brkId, accId, md);
    });

    $("#brokerIdReject-1").val(window.myConfig.brokerName);
    $("#accountIdReject-1").val(accountId);
    $("#rejectModal").modal("show");
  },
  showApproveForm: function (mode, accountId) {
    if (mode == "Lots") {
      $("#modeApprove-1").val(0);
    } else if (mode == "Multiplier") {
      $("#modeApprove-1").val(1);
    } else if (mode == "LAMM") {
      $("#modeApprove-1").val(2);
    } else if (mode == "PAMM") {
      $("#modeApprove-1").val(3);
    }

    $("#btnApprove").on("click", function () {
      let brkId = $("#brokerIdApprove-1").val();
      let accId = $("#accountIdApprove-1").val();
      let md = parseInt($("#modeApprove-1").val());
      $("#approveModal").modal("hide");
      cptdDashboard.approveCopyTrade(brkId, accId, md);
    });

    $("#brokerIdApprove-1").val(window.myConfig.brokerName);
    $("#accountIdApprove-1").val(accountId);
    $("#approveModal").modal("show");
  },
  getCptd: function () {
    let that = this;
    fetch(window.myConfig.copyTradingSharedList)
    .then(response => response.json())
    .then(data => {
      let sortedData = data.sort((a, b) => {
        return parseFloat(b.pl) - parseFloat(a.pl);
      })

      for (let i in sortedData) {
        let account = sortedData[i];

        let signalName = typeof account.signalName == "string" ? (account.signalName == "" ? "__" : account.signalName) : "__";
        let balance = Math.round((account.balance + account.pl) * 100) / 100;
        let profitRate = Math.round(account.balance != 0 ? account.pl * 10000 / account.balance : 0) / 100;
        let cpTrdCommissionRate = typeof account.cpTrdCommissionRate != "undefined" ? Math.round(account.cpTrdCommissionRate * 100) + "%" : 0;
        let cpTrdPeriod = typeof account.cpTrdPeriod != "undefined" ? account.cpTrdPeriod : 0;
        if (cpTrdPeriod == 86400) {
          cpTrdPeriod = "1D";
        } else if (cpTrdPeriod == 604800) {
          cpTrdPeriod = "1W";
        } else if (cpTrdPeriod == 1209600) {
          cpTrdPeriod = "2W";
        } else if (cpTrdPeriod == 2419200) {
          cpTrdPeriod = "4W";
        } else {
          cpTrdPeriod = "Free";
        }

        that.pro.push([
          account.accountId,
          signalName,
          balance,
          profitRate,
          cpTrdCommissionRate,
          cpTrdPeriod,
          account.tradeNum,
          account.brokerName + "-" + account.accountId
        ]);
      }

      that.renderCptd();
    });
  },
  genProRow: function (pro) {
    // Mock data for testing
    let accountId = "123456";
    let balance = "$10,000";
    let profitRate = 15; // Assuming a positive profit rate for example
    let cpTrdCommissionRate = "2%";
    let cpTrdPeriod = "Monthly";
    let tradeNum = 1; // Assuming there's a trade
    let graphUrl = "https://s3.eu-central-1.amazonaws.com/fintechee.net/trades2/fe-1026069.png"; // Graph image URL

    // Determine class for profit rate
    let cls = profitRate >= 0 ? "success" : "danger";

    // Construct HTML structure with adjustments for graph placement
    let proHtml = `
    <div class="pro-cptd">
        <div class="d-flex justify-content-start align-items-center mt-2">
            <div class="pro-desc ms-3">
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div>
                        <h4>Account:</h4>
                    </div>
                    <div>
                        <div class="fw-bold text-primary">${accountId}</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div>
                        <h4>Balance:</h4>
                    </div>
                    <div>
                        <div class="fw-bold text-${cls}">${balance}</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div>
                        <h4>Profit Rate:</h4>
                    </div>
                    <div>
                        <div class="fw-bold text-${cls}">${profitRate} %</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div>
                        <h4>Fee Rate:</h4>
                    </div>
                    <div>
                        <div class="fw-bold text-danger">${cpTrdCommissionRate}</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div>
                        <h4>Period:</h4>
                    </div>
                    <div>
                        <div class="fw-bold">${cpTrdPeriod}</div>
                    </div>
                </div>
                <div class="d-flex justify-content-between w-100 mt-2">
                    <div class="btn-group">
                        <button type="button" class="btn" id="btnShowCopyTrading">CPTD</button>
                        <button type="button" class="btn" id="btnShowLamm">LAMM</button>
                        <button type="button" class="btn" id="btnShowPamm">PAMM</button>
                    </div>
                </div>
            </div>
            <div class="graph-circle">
                ${tradeNum === 0 ? '' : `<img class="img-fluid rounded-circle" src="${graphUrl}" alt="Graph Image">`}
            </div>
        </div>
    </div>`;

    return proHtml;
},

  renderCptd: function (mode) {
    let that = this;

    if (!$.fn.dataTable.isDataTable("#proTable")) {
      let table = $("#proTable").DataTable({
        columns: [
          {
            title: "Pro",
            render: function(data, type, row) {
              return cptdDashboard.genProRow(row);
            }
          }
        ],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false,
      });

      this.proDataTable = $("#proTable").DataTable();
      this.prodataTable = $("#proTable").dataTable();

      $("#proTable tbody").on("click", "[id*=btnShowCopyTrading]", function () {
        if (that.proDataTable != null) {
          let data = that.proDataTable.row($(this).parents("tr")).data();
          let pro = data[7].split("-");

          that.showCopyTradeForm("cptd", pro[0], pro[1]);
        }
      });

      $("#proTable tbody").on("click", "[id*=btnShowLamm]", function () {
        if (that.proDataTable != null) {
          let data = that.proDataTable.row($(this).parents("tr")).data();
          let pro = data[7].split("-");

          that.showCopyTradeForm("lamm", pro[0], pro[1]);
        }
      });

      $("#proTable tbody").on("click", "[id*=btnShowPamm]", function () {
        if (that.proDataTable != null) {
          let data = that.proDataTable.row($(this).parents("tr")).data();
          let pro = data[7].split("-");

          that.showCopyTradeForm("pamm", pro[0], pro[1]);
        }
      });
    } else {
      if (this.proDataTable.column(0).data().length > 0) {
        return;
      }
    }

    for (let i in this.pro) {
      this.proDataTable.row.add(this.pro[i]).draw(false);
    }
  },
  loadFollowing: function (res) {
    for (let i in res.copyTrades) {
      let ct = res.copyTrades[i];
      if (ct.copyTrading == window.myConfig.accountId) {
        if (ct.mode == 0 || ct.mode == 1) {
          let tradeNum = 0;
          for (let j in this.pro) {
            if (ct.comment == null || ct.comment == "") {
              if (ct.brokerName + "-" + ct.copyTraded == this.pro[j][7]) {
                tradeNum = this.pro[j][6];
                break;
              }
            } else {
              if (ct.comment.replace(":", "-") == this.pro[j][7]) {
                tradeNum = this.pro[j][6];
                break;
              }
            }
          }

          this.copyTrading.push([
            (ct.comment == null || ct.comment == "") ? ct.copyTraded : ct.comment.split(":")[1],
            ct.mode == 0 ? "Lots" : "Multiplier",
            ct.bReverse,
            ct.multiplier,
            ct.state == 0 ? "Pending" : "Approved",
            (ct.comment == null || ct.comment == "") ? (ct.brokerName + "-" + ct.copyTraded) : ct.comment.replace(":", "-"),
            tradeNum,
            (ct.comment == null || ct.comment == "") ? (ct.copyTraded + "::") : (ct.copyTraded + ":" + ct.comment)
          ]);
        } else if (ct.mode == 2) {
          let tradeNum = 0;
          for (let j in this.pro) {
            if (ct.comment == null || ct.comment == "") {
              if (ct.brokerName + "-" + ct.copyTraded == this.pro[j][7]) {
                tradeNum = this.pro[j][6];
                break;
              }
            }
          }

          this.lamm.push([
            ct.copyTraded,
            "LAMM",
            ct.bReverse,
            ct.state == 0 ? "Pending" : "Approved",
            ct.brokerName + "-" + ct.copyTraded,
            tradeNum
          ]);
        } else if (ct.mode == 3) {
          let tradeNum = 0;
          for (let j in this.pro) {
            if (ct.comment == null || ct.comment == "") {
              if (ct.brokerName + "-" + ct.copyTraded == this.pro[j][7]) {
                tradeNum = this.pro[j][6];
                break;
              }
            }
          }

          this.pamm.push([
            ct.copyTraded,
            "PAMM",
            ct.state == 0 ? "Pending" : "Approved",
            ct.brokerName + "-" + ct.copyTraded,
            tradeNum
          ]);
        }
      }
    }

    this.renderFollowing();
  },
  genFollowingRow: function (cptd) {
    let mode = cptd[1];

    if (mode == "Lots" || mode == "Multiplier") {
      let accountId = cptd[5].split("-")[1];
      let reverse = cptd[2];
      let multiplier = cptd[3];
      let state = cptd[4];
      let graphId = cptd[5];
      let tradeNum = cptd[6];

      let cls = null;
      if (state == "Approved") {
        cls = "primary";
      } else {
        cls = "danger";
      }

      let cptdHtml =
      `<div class="pro-cptd">
        <div class="d-flex justify-content-between w-100 mt-2">
          <div class="graph">` +
          (tradeNum == 0 ? "" : `<img class="img-fluid" src="https://s3.eu-central-1.amazonaws.com/fintechee.net/trades2/${graphId}.png" alt="">`) +
          `</div>
          <div class="following-desc">
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Account:</div>
              </div>
              <div>
                <div class="fw-bold text-primary">${accountId}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Mode:</div>
              </div>
              <div>
                <div class="fw-bold">${mode}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Lots / Multiplier:</div>
              </div>
              <div>
                <div class="fw-bold">${multiplier}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Reverse:</div>
              </div>
              <div>
                <div class="fw-bold">${reverse}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>State:</div>
              </div>
              <div>
                <div class="fw-bold text-${cls}">${state}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div class="follow-box">
                <div class="d-flex gap-2" id="btnShowUnfollowCptd">
                  <div>Unfollow
                  <i class="bi bi-hand-thumbs-down-fill text-red"></i></div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>`;

      return cptdHtml;
    } else if (mode == "LAMM") {
      let accountId = cptd[4].split("-")[1];
      let reverse = cptd[2];
      let state = cptd[3];
      let graphId = cptd[4];
      let tradeNum = cptd[5];

      let cls = null;
      if (state == "Approved") {
        cls = "primary";
      } else {
        cls = "danger";
      }

      let cptdHtml =
      `<div class="pro-cptd">
        <div class="d-flex justify-content-between w-100 mt-2">
          <div class="graph">` +
          (tradeNum == 0 ? "" : `<img class="img-fluid" src="https://s3.eu-central-1.amazonaws.com/fintechee.net/trades2/${graphId}.png" alt="">`) +
          `</div>
          <div class="following-desc">
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Account:</div>
              </div>
              <div>
                <div class="fw-bold text-primary">${accountId}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Reverse:</div>
              </div>
              <div>
                <div class="fw-bold">${reverse}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>State:</div>
              </div>
              <div>
                <div class="fw-bold text-${cls}">${state}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div class="follow-box">
                <div class="d-flex gap-2" id="btnShowUnfollowLamm">
                  <div>Unfollow
                  <i class="bi bi-hand-thumbs-down-fill text-red"></i></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`;
      return cptdHtml;
    } else {
      let accountId = cptd[3].split("-")[1];
      let state = cptd[2];
      let graphId = cptd[3];
      let tradeNum = cptd[4];

      let cls = null;
      if (state == "Approved") {
        cls = "primary";
      } else {
        cls = "danger";
      }

      let cptdHtml =
      `<div class="pro-cptd">
        <div class="d-flex justify-content-between w-100 mt-2">
          <div class="graph">` +
          (tradeNum == 0 ? "" : `<img class="img-fluid" src="https://s3.eu-central-1.amazonaws.com/fintechee.net/trades2/${graphId}.png" alt="">`) +
          `</div>
          <div class="following-desc">
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>Account:</div>
              </div>
              <div>
                <div class="fw-bold text-primary">${accountId}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div>
                <div>State:</div>
              </div>
              <div>
                <div class="fw-bold text-${cls}">${state}</div>
              </div>
            </div>
            <div class="d-flex justify-content-between w-100 mt-2">
              <div class="follow-box">
                <div class="d-flex gap-2" id="btnShowUnfollowPamm">
                  <div>Unfollow
                  <i class="bi bi-hand-thumbs-down-fill text-red"></i></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`;
      return cptdHtml;
    }
  },
  renderFollowing: function () {
    let that = this;

    if (!$.fn.dataTable.isDataTable("#followingTable")) {
      let table = $("#followingTable").DataTable({
        columns: [
          {
            title: "Pro",
            render: function(data, type, row) {
              return cptdDashboard.genFollowingRow(row);
            }
          }
        ],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false,
      });

      this.followingDataTable = $("#followingTable").DataTable();
      this.followingdataTable = $("#followingTable").dataTable();

      $("#followingTable tbody").on("click", "[id*=btnShowUnfollowCptd]", function () {
        if (that.followingDataTable != null) {
          let data = that.followingDataTable.row($(this).parents("tr")).data();
          let pro = data[5].split("-");

          that.showUnfollowForm(data[1], pro[0], pro[1]);
        }
      });

      $("#followingTable tbody").on("click", "[id*=btnShowUnfollowLamm]", function () {
        if (that.followingDataTable != null) {
          let data = that.followingDataTable.row($(this).parents("tr")).data();
          let pro = data[4].split("-");

          that.showUnfollowForm("LAMM", pro[0], pro[1]);
        }
      });

      $("#followingTable tbody").on("click", "[id*=btnShowUnfollowPamm]", function () {
        if (that.followingDataTable != null) {
          let data = that.followingDataTable.row($(this).parents("tr")).data();
          let pro = data[3].split("-");

          that.showUnfollowForm("PAMM", pro[0], pro[1]);
        }
      });
    } else {
      if (this.followingDataTable.column(0).data().length > 0) {
        return;
      }
    }

    for (let i in this.copyTrading) {
      this.followingDataTable.row.add(this.copyTrading[i]).draw(false);
    }
    for (let i in this.lamm) {
      this.followingDataTable.row.add(this.lamm[i]).draw(false);
    }
    for (let i in this.pamm) {
      this.followingDataTable.row.add(this.pamm[i]).draw(false);
    }
  },
  getCopyTrades: function (accountId, tradeToken) {
    try {
      $.ajax({
        type: "GET",
        url: `${window.myConfig.brokerProtocol}${window.myConfig.brokerDomain}${window.myConfig.brokerPort}/accoumns/${window.myConfig.brokerName}/${accountId}/copyTrades`,
        headers: {
          "Content-Type": "application/json",
          'Authorization': `Bearer TRADE ${tradeToken}`,
        }
      })
      .done(function(res) {
        cptdDashboard.loadFollowing(res);
        cptdDashboard.loadFollowers(res);
      })
      .fail(function(data) {});
    } catch (error) {
      console.error('COPYTRADES Error:', error);
    }
  },
  loadFollowers: function (res) {
    for (let i in res.copyTrades) {
      let ct = res.copyTrades[i];
      if (ct.copyTraded == this.accountId) {
        this.copyTraded.push([
          ct.copyTrading,
          ct.mode == 0 ? "Lots" : (ct.mode == 1 ? "Multiplier" : (ct.mode == 2 ? "LAMM" : "PAMM")),
          ct.state == 0 ? "Pending" : "Approved",
          ct.state
        ]);
      }
    }

    this.renderFollowers();
  },
  renderFollowers: function () {
    let that = this;

    if (!$.fn.dataTable.isDataTable("#followerTable")) {
      let table = $("#followerTable").DataTable({
        columns: [
          {
            title: "Follower"
          },
          {
            title: "Mode"
          },
          {
            title: "State"
          },
          {
            title: "Action"
          }
        ],
        "columnDefs": [{
          targets: -1,
          data: null,
          defaultContent:
          '<button class="btn btn-success" id="btnApproveCopyTrade" title="Approve"><i class="bi bi-check"></i></button>' +
          '<button class="btn btn-danger" id="btnRejectCopyTrade" title="Reject"><i class="bi bi-x-circle"></i></button>'
        }],
        "paging": false,
        "lengthChange": false,
        "searching": false,
        "info": false,
        "autoWidth": false,
      });

      this.followerDataTable = $("#followerTable").DataTable();
      this.followerdataTable = $("#followerTable").dataTable();

      $("#followerTable tbody").on("click", "[id*=btnRejectCopyTrade]", function () {
        if (that.followerDataTable != null) {
          let data = that.followerDataTable.row($(this).parents("tr")).data();

          that.showRejectForm(data[1], data[0]);
        }
      });

      $("#followerTable tbody").on("click", "[id*=btnApproveCopyTrade]", function () {
        if (that.followerDataTable != null) {
          let data = that.followerDataTable.row($(this).parents("tr")).data();

          that.showApproveForm(data[1], data[0]);
        }
      });
    } else {
      if (this.followerDataTable.column(0).data().length > 0) {
        return;
      }
    }

    for (let i in this.followers) {
      this.followerDataTable.row.add(this.followers[i]).draw(false);
    }
  }
}
