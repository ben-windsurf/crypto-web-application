// Function to render favorites
function renderFavorites(container, data, mode, action) {
  const favoritesContent = document.getElementById(container);

  // Clear previous content
  favoritesContent.innerHTML = "";

  // Render each item in data
  data.forEach((item, index) => {
    const currencyName = item.displayName;
    const currencyName2 = currencyName.replaceAll("/", "_");
    // const upValue = item.up;
    // const downValue = item.down;

    // Create table structure
    const currencyTable = document.createElement("table");
    currencyTable.classList.add("currency-table");

    // Create table row
    const dataRow = currencyTable.insertRow();

    // Currency name cell
    const nameDataCell = dataRow.insertCell();
    nameDataCell.innerHTML = `<div class="text-primary">${currencyName}</div><div><span id="symbol_${currencyName2}_p_${mode}"></span><span id="symbol_${currencyName2}_s_${mode}"></span></div>`;
    nameDataCell.classList.add("name-cell");

    // Up and Down values cell
    const valuesDataCell = dataRow.insertCell();
    const upDownWrapper = document.createElement("div");
    upDownWrapper.innerHTML = `<div class="ml-5"><span id="symbol_${currencyName2}_b_${mode}"></span></div><div>L:<span id="symbol_${currencyName2}_l_${mode}"></span></div>`;
    valuesDataCell.appendChild(upDownWrapper);
    valuesDataCell.classList.add("values-cell");

    // Additional cell with the same content
    const additionalDataCell = dataRow.insertCell();
    additionalDataCell.innerHTML = `<div class="ml-5"><span id="symbol_${currencyName2}_a_${mode}"></span></div><div>H:<span id="symbol_${currencyName2}_h_${mode}"></span></div>`;
    additionalDataCell.classList.add("values-cell");

    // Add bottom border to data row
    dataRow.classList.add("currency-table-row");

    // Create button container
    const buttonContainer = document.createElement("div");
    buttonContainer.classList.add("button-container");

    // Create buttons with different colors and icons
    const buttons = [{
        color: "white",
        icon: "🗑️",
        action: () => action.deleteFavSymbol(item.displayName)
      },
      {
        color: "blue",
        icon: "B",
        action: () => action.showOrderForm(item.displayName, "BUY", mode)
      },
      {
        color: "red",
        icon: "S",
        action: () => action.showOrderForm(item.displayName, "SELL", mode)
      },
      {
        color: "orange",
        icon: "📊",
        action: () => action.addChart(item.displayName)
      }
    ];

    buttons.forEach(({
      color,
      icon,
      action
    }) => {
      const button = document.createElement("button");
      button.classList.add(`button-${color}`);
      button.innerHTML = icon;
      if (action) button.onclick = action;
      buttonContainer.appendChild(button);
    });

    // Append button container to the data row
    dataRow.appendChild(buttonContainer);

    // Overlay for hiding text behind buttons
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");
    overlay.innerHTML = `<p>${currencyName}</p>`;
    dataRow.appendChild(overlay);

    // Append table to favorites content
    favoritesContent.appendChild(currencyTable);
  });
}

function showTab(tabId) {

  console.log("tab id ", tabId)
  // Hide all tab contents
  var tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(function(tabContent) {
    tabContent.classList.remove('active');
  });

  // Remove active class from all tab buttons
  var tabButtons = document.querySelectorAll('.tab-button');
  tabButtons.forEach(function(tabButton) {
    tabButton.classList.remove('active');
  });

  // Show the selected tab and add active class to the button
  document.getElementById(tabId).classList.add('active');
  event.target.classList.add('active');
}

function showTabSmall(tabId) {
  // Hide all tab content
  const tabContents = document.querySelectorAll('.tab-content-small');
  tabContents.forEach(tabContent => {
    tabContent.classList.remove('active');
  });

  // Remove active class from all tab buttons
  const tabButtons = document.querySelectorAll('.tab-button-small');
  tabButtons.forEach(tabButton => {
    tabButton.classList.remove('active');
  });

  // Show the selected tab content
  const selectedTabContent = document.getElementById(tabId);
  selectedTabContent.classList.add('active');

  // Add active class to the clicked tab button
  const clickedTabButton = document.querySelector(`button[onclick="showTabSmall('${tabId}')"]`);
  clickedTabButton.classList.add('active');
}

document.addEventListener('DOMContentLoaded', function() {
  const toggleSidebarItem = document.getElementById('toggle-sidebar-content');
  const sidebarContentContainer = document.querySelector('.sidebar-content-container');

  toggleSidebarItem.addEventListener('click', function(e) {
    e.preventDefault();
    sidebarContentContainer.classList.toggle('show');
  });
});

function renderCards(container, data, mode, action) {
  const divContainer = document.getElementById(container);

  // Clear previous content
  divContainer.innerHTML = "";

  data.forEach(item => {
    const card = document.createElement("div");
    card.classList.add("forex-card", "px-3", "d-flex", "justify-content-between", "align-items-center");

    const info = document.createElement("div");
    info.classList.add("d-flex", "mt-2", "gap-2");

    const currencyName = document.createElement("p");
    currencyName.textContent = item.displayName;
    info.appendChild(currencyName);

    const smallText = document.createElement("small");
    smallText.textContent = "Forex";
    smallText.classList.add("text-secondary", "small");
    info.appendChild(smallText);

    card.appendChild(info);

    const addButton = document.createElement("button");
    addButton.setAttribute("type", "button");
    addButton.classList.add("btn", "btn-success");
    if (action) addButton.onclick = () => action.addFavSymbol(item);

    const plusIcon = document.createElement("i");
    plusIcon.classList.add("bi", "bi-plus");
    addButton.appendChild(plusIcon);

    card.appendChild(addButton);

    divContainer.appendChild(card);
  });
}




document.addEventListener('DOMContentLoaded', function() {
  const sidebarItems = document.querySelectorAll('.sidebar-item a');

  sidebarItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('data-target');
      const targetContent = document.getElementById(targetId);

      if (targetContent) {
        const allContent = document.querySelectorAll('.main-content > div');
        allContent.forEach(content => {
          content.style.display = 'none';
        });

        targetContent.style.display = 'block';
      }
    });
  });
});




document.querySelectorAll('.unique-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    document.querySelectorAll('.unique-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.unique-tab-content').forEach(content => content.classList.remove('active'));

    this.classList.add('active');
    document.getElementById(this.getAttribute('data-tab')).classList.add('active');
  });
});

document.querySelectorAll('.unique-accordion-header').forEach(header => {
  header.addEventListener('click', function() {
    const content = this.nextElementSibling;
    const arrow = this.querySelector('.unique-arrow');

    if (content.classList.contains('active')) {
      content.classList.remove('active');
      this.classList.remove('active');
    } else {
      document.querySelectorAll('.unique-accordion-content').forEach(item => item.classList.remove('active'));
      document.querySelectorAll('.unique-accordion-header').forEach(item => item.classList.remove('active'));

      content.classList.add('active');
      this.classList.add('active');
    }
  });
});


function switchTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('custom-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('custom-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`custom-${tabName}-content`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`custom-tab-${tabName}`).classList.add('active');
}

function switchLammTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('lamm-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('lamm-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`lamm-${tabName}-content`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`lamm-tab-${tabName}`).classList.add('active');
}

// Initialize the first tab as active
document.addEventListener('DOMContentLoaded', function() {
  switchLammTab('user');
});


function switchPammTab(tabName) {
  // Hide all PAMM tab contents
  const pammTabContents = document.getElementsByClassName('pamm-tab-content');
  for (let content of pammTabContents) {
    content.style.display = 'none';
  }

  // Deactivate all PAMM tabs
  const pammTabs = document.getElementsByClassName('pamm-tab-button');
  for (let tab of pammTabs) {
    tab.classList.remove('active');
  }

  // Show the selected PAMM tab content
  document.getElementById(`pamm-${tabName}-content`).style.display = 'block';

  // Activate the selected PAMM tab
  document.getElementById(`pamm-tab-${tabName}`).classList.add('active');
}

// Initialize the first PAMM tab as active
document.addEventListener('DOMContentLoaded', function() {
  switchPammTab('user');
});

function switchTradingTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('trading-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('trading-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`trading-${tabName}-content`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`trading-tab-${tabName}`).classList.add('active');
}

function toggleOrd(event) {
  const allOrd = document.querySelectorAll('.ord-order');
  const currentOrd = event.target.closest('.ord-order'); // find the closest .faq ancestor
  const currentOrdPanel = currentOrd.querySelector('.ord-panel');
  const isOpen = currentOrdPanel.style.display === 'block';

  allOrd.forEach(ord => {
    ord.querySelector('.ord-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentOrdPanel.style.display = 'block';
  }
}

function togglePos(event) {
  const allPos = document.querySelectorAll('.pos-order');
  const currentPos = event.target.closest('.pos-order'); // find the closest .faq ancestor
  const currentPosPanel = currentPos.querySelector('.pos-panel');
  const isOpen = currentPosPanel.style.display === 'block';

  allPos.forEach(pos => {
    pos.querySelector('.pos-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentPosPanel.style.display = 'block';
  }
}

function toggleHist(event) {
  const allHist = document.querySelectorAll('.pos-hist');
  const currentHist = event.target.closest('.pos-hist'); // find the closest .faq ancestor
  const currentDetail = currentHist.querySelector('.hist-panel');
  const isOpen = currentDetail.style.display === 'block';

  allHist.forEach(hist => {
    hist.querySelector('.hist-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function toggleProCptd(event) {
  const container = document.getElementById('divProCopyTrading');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function toggleProLamm(event) {
  const container = document.getElementById('divProLamm');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function toggleProPamm(event) {
  const container = document.getElementById('divProPamm');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function toggleCptd(event) {
  const container = document.getElementById('divCopyTrading');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function toggleLamm(event) {
  const container = document.getElementById('divLamm');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function togglePamm(event) {
  const container = document.getElementById('divPamm');
  const allPro = container.querySelectorAll('.pro-cptd');
  const currentPro = event.target.closest('.pro-cptd'); // find the closest .faq ancestor
  const currentDetail = currentPro.querySelector('.pro-panel');
  const isOpen = currentDetail.style.display === 'block';

  allPro.forEach(pro => {
    pro.querySelector('.pro-panel').style.display = 'none';
  });

  if (!isOpen) {
    currentDetail.style.display = 'block';
  }
}

function switchOrderTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('trading-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('trading-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`${tabName}-content-1`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`tab-${tabName}-1`).classList.add('active');
}

function switchOrderSmallTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('trading-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('trading-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`${tabName}-content-2`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`tab-${tabName}-2`).classList.add('active');
}

function switchCptdTab(tabName) {
  // Hide all tab contents
  const tabContents = document.getElementsByClassName('cptd-tab-content');
  for (let content of tabContents) {
    content.style.display = 'none';
  }

  // Deactivate all tabs
  const tabs = document.getElementsByClassName('cptd-tab-button');
  for (let tab of tabs) {
    tab.classList.remove('active');
  }

  // Show the selected tab content
  document.getElementById(`${tabName}-content`).style.display = 'block';

  // Activate the selected tab
  document.getElementById(`tab-${tabName}`).classList.add('active');
}
